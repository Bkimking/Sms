<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- HeaderItem Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <h1 class="mt-4">Add Header Item</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Add Header Item</li>
                </ol>
                <div class="card mb-4">
                    <div class="card-body">
                        This is the Add Header Item page. If you encounter any problems, please contact the developers.
                        <a href="#mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Form for Adding Header Item -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-plus-circle"></i> Add Header Item
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('header.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="headertitle" class="form-label">Header Title</label>
                                <input type="text" name="headertitle" id="headertitle" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label for="headersubtitle" class="form-label">Header Subtitle</label>
                                <input type="text" name="headersubtitle" id="headersubtitle" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label for="headerparagraph" class="form-label">Header Content</label>
                                <input type="text" name="headerparagraph" id="headerparagraph" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label for="headerimg" class="form-label">Header Image</label>
                                <input type="file" name="headerimg" id="headerimg" class="form-control">
                            </div>

                            <button type="submit" class="btn btn-primary">Add Header Item</button>
                            <!-- Back Button -->
                            <a href="<?php echo e(route('admin')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                            <a href="<?php echo e(route('header.manage')); ?>" class="btn btn-warning">Manage Header Item</a>
                        </form>
                    </div>
                </div>
            </main>
            <!-- End HeaderItem Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html><?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\header\create.blade.php ENDPATH**/ ?>