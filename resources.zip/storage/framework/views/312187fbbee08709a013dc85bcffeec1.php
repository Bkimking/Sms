<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- courseshow Section -->
    <section id="courseshow" class="container py-5">
        <h1 class="text mb-4">
            <?php echo e($course->course_name); ?>

        </h1>

        <div class="row">
            <!-- Left Section (80%) -->
            <div class="col-md-8">
                <img src="<?php echo e(Storage::url($course->course_img)); ?>" width="300" height="300"
                    class="img-fluid mb-4 img-fluid" alt="<?php echo e($course->course_name); ?>">

                <p><?php echo e($course->course_description); ?></p>

                <!-- Action Buttons -->
                <div class="mt-4">
                    <!-- Dynamic Back to Courses Button -->
                    <?php if(strtolower($course->category) === 'certificate'): ?>
                        <a href="<?php echo e(route('certificatecourses')); ?>" class="btn btn-secondary">Back to Certificate
                            Courses</a>
                    <?php elseif(strtolower($course->category) === 'diploma'): ?>
                        <a href="<?php echo e(route('diplomacourses')); ?>" class="btn btn-secondary">Back to Diploma Courses</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('shortcourses')); ?>" class="btn btn-secondary">Back to Short Courses</a>
                    <?php endif; ?>

                    <!-- Apply for Course -->
                    <a href="<?php echo e(route('apply.page', ['type' => 'course', 'id' => $course->id])); ?>"
                        class="btn btn-danger">Apply for Course</a>

                </div>
            </div>

            <!-- Right Section (20%) -->
            <div class="col-md-4">
                <!-- Card 1: Other Courses in the Same Category -->
                <?php if($otherCourses->count() > 0): ?>
                    <div class="card mb-4">
                        <div class="card-header bg-danger text-white">Other <?php echo e($course->category); ?> Courses</div>
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $otherCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('course.show', $otherCourse->id)); ?>"><?php echo e($otherCourse->course_name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Card 2: Course Categories -->
                <div class="card mb-4">
                    <div class="card-header bg-danger text-white">Course Categories</div>
                    <div class="card-body">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(route('certificatecourses')); ?>">Certificate Courses</a></li>
                            <!-- COMMENTED DIPLOMA -->
                            <!-- li><a href="<?php echo e(route('diplomacourses')); ?>">Diploma Courses</a></li -->
                            <li><a href="<?php echo e(route('shortcourses')); ?>">Short Courses</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Card 3: Sub-courses under the Course -->
                <?php if($subCourses->isNotEmpty()): ?>
                    <div class="card mb-4">
                        <div class="card-header bg-danger text-white">
                            Sub-Courses Under <?php echo e($course->course_name); ?>

                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $subCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('subcourses.show', $subCourse->id)); ?>">
                                            <?php echo e($subCourse->sub_course_name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

            </div>

        </div> <!-- End of Row -->
    </section>

    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\showcourse.blade.php ENDPATH**/ ?>