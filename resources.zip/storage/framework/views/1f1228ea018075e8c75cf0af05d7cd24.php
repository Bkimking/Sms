<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Add About Feature</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- About Features Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Add About Page</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Add About page</li>
                </ol>
                
                <div class="card mb-4">
                    <div class="card-body">
                        You are in new About Page. If you encounter any problems, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Form for Adding About Feature -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-plus-circle"></i> Add About 
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('about.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="abouttitle" class="form-label">Title</label>
                                <input type="text" name="abouttitle" id="abouttitle" class="form-control"
                                    placeholder="Enter title here" required>
                            </div>

                            <div class="mb-3">
                                <label for="aboutsubtitle" class="form-label">Subtitle</label>
                                <input type="text" name="aboutsubtitle" id="aboutsubtitle" class="form-control"
                                    placeholder="Enter subtitle here">
                            </div>

                            <div class="mb-3">
                                <label for="aboutparagraph" class="form-label">Description</label>
                                <textarea name="aboutparagraph" id="aboutparagraph" class="form-control" rows="5" 
                                    placeholder="Enter a detailed description" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="aboutimg" class="form-label">Image</label>
                                <input type="file" name="aboutimg" id="aboutimg" class="form-control">
                            </div>

                            <button type="submit" class="btn btn-primary">Add Feature</button>
                        </form>
                    </div>
                </div>
            </main>
            <!-- End About Features Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\about\create.blade.php ENDPATH**/ ?>