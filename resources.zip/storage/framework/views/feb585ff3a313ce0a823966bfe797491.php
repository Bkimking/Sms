<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Application Details</title>

    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="sb-nav-fixed">

    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="layoutSidenav">

        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div id="layoutSidenav_content">

            <main class="container-fluid px-4">
                <h1 class="mt-4">Student Application Details</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.applications')); ?>">Student Applications</a></li>
                    <li class="breadcrumb-item active">Application Details</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        <h4><?php echo e($application->first_name); ?> <?php echo e($application->surname); ?></h4>
                        <p><strong>Email:</strong> <?php echo e($application->email); ?></p>
                        <p><strong>Gender:</strong> <?php echo e(ucfirst($application->gender)); ?></p>
                        <p><strong>Telephone:</strong> <?php echo e($application->tel); ?></p>
                        <p><strong>Date of Birth:</strong> <?php echo e($application->dob); ?></p>
                        <p><strong>Status:</strong> <?php echo e(ucfirst($application->status)); ?></p>

                        <div class="mt-3">
                            <a href="<?php echo e(route('admin.applications')); ?>" class="btn btn-secondary">Back</a>
                        </div>
                    </div>
                </div>
            </main>

            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>

    </div>

    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\student\details.blade.php ENDPATH**/ ?>