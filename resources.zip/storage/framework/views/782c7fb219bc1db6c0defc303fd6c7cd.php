<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC - Login</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/studloginstyle.css'); ?>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="container mt-5 d-flex justify-content-center align-items-center vh-100">
            <div class="card shadow-lg p-4 d-flex flex-column flex-md-row">
                <!-- Logo / Illustration -->
                <div class="me-md-4 mb-4 mb-md-0 text-center">
                    <img src="<?php echo e(asset('imgs/logo.jpg')); ?>" alt="Student Illustration" class="img-fluid"
                        style="max-width: 300px;">
                </div>

                <div class="flex-fill">
                    <h2 class="text-center mb-4 text-primary">Student Login</h2>

                    <form method="POST" action="<?php echo e(route('student.login')); ?>">
                        <?php echo csrf_field(); ?>

                        <!-- Admission Number -->
                        <div class="mb-3">
                            <label for="admission_no" class="form-label text-primary">Admission No</label>
                            <input type="text"
                                class="form-control border-primary <?php $__errorArgs = ['admission_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="admission_no" name="admission_no" placeholder="Enter Admission No" required
                                value="<?php echo e(old('admission_no')); ?>">
                            <?php $__errorArgs = ['admission_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Password -->
                        <div class="mb-3 position-relative">
                            <label for="password" class="form-label text-primary">Password</label>
                            <div class="input-group">
                                <input type="password"
                                    class="form-control border-primary <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="password" name="password" placeholder="Enter Password" required>
                                <button type="button" class="btn btn-outline-primary" id="togglePassword">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="text-end mt-1">
                                <?php if(Route::has('student.password.request')): ?>
                                    <a href="<?php echo e(route('student.password.request')); ?>"
                                        class="text-decoration-none text-primary">Forgot Password?</a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>


    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Password Toggle Script -->
    <script>
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordField = document.getElementById('password');
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            this.innerHTML = type === 'password' ? '<i class="bi bi-eye"></i>' : '<i class="bi bi-eye-slash"></i>';
        });
    </script>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\auth\studentlogin.blade.php ENDPATH**/ ?>