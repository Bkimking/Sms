<!-- this is dashboard for teacher -->

<!-- dashboard -->

<!DOCTYPE html>
<html lang="en">

<head>

    <title>teacher Dashboard</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->

</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Main Content -->

            <main>
                <div class="container-fluid px-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('warning')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?php echo e(session('warning')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <h1 class="mt-4">Welcome, teacher!</h1>

                    <div class="card mb-4">
                        <div class="card-body">
                            This is the teacher Dashboard page. If you encounter any issues, please contact the
                            developers.
                            <a href="#mailto:developers@example.com">Contact Developers</a>.
                        </div>
                    </div>

                    <p class="lead">This is your dashboard</p>

                </div>
            </main>
            <!-- End Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\teacher\dashboard.blade.php ENDPATH**/ ?>