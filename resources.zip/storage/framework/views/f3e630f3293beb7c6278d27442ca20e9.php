<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Edit Staff</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Content -->
            <main class="container-fluid px-4">
                <h1 class="mt-4">Edit Staff Member</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('staff.manage')); ?>">Manage Staff</a></li>
                    <li class="breadcrumb-item active">Edit Staff</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Edit Staff page. If you encounter any issues, please contact the developers.
                        <a href="#mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-user-edit"></i> Edit Staff Member
                    </div>
                    <div class="card-body">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('staff.update', $staff->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row">
                                <!-- Staff ID Field -->
                                <div class="mb-3">
                                    <label for="staff_id" class="form-label">Staff ID</label>
                                    <div class="input-group">
                                        <input type="text" name="staff_id" id="staff_id" class="form-control"
                                            value="<?php echo e(optional($staff->staffid)->staff_id); ?>" readonly>
                                        <button type="button" class="btn btn-outline-secondary" id="generateStaffId">
                                            <i class="fas fa-key"></i> <!-- Font Awesome Key Icon -->
                                        </button>
                                        <!-- Lock/Unlock Button -->
                                        <button type="button" class="btn btn-outline-secondary" id="toggleStaffIdLock">
                                            <i id="lockIcon" class="fas fa-lock"></i> <!-- Default Locked Icon -->
                                        </button>
                                    </div>
                                    <small class="text-muted">Staff ID cannot be changed unless unlocked.</small>
                                </div>

                                <!-- Name Field -->
                                <div class="mb-3 ">
                                    <label for="name" class="form-label">Username</label>
                                    <input type="text" name="name" id="name" class="form-control"
                                        value="<?php echo e($staff->name); ?>" required>
                                </div>

                                <!-- Email Field -->
                                <div class="mb-3 ">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" name="email" id="email" class="form-control"
                                        value="<?php echo e($staff->email); ?>" required>
                                </div>

                                <!-- Role Selection -->
                                <div class="mb-3">
                                    <label for="role" class="form-label">Role</label>
                                    <select name="role" id="role" class="form-control" required>
                                        <option value="1" <?php echo e($staff->role == 1 ? 'selected' : ''); ?>>Admin</option>
                                        <option value="3" <?php echo e($staff->role == 3 ? 'selected' : ''); ?>>Super Admin
                                        </option>
                                        <option value="4" <?php echo e($staff->role == 4 ? 'selected' : ''); ?>>Teacher
                                        </option>
                                        <option value="5" <?php echo e($staff->role == 5 ? 'selected' : ''); ?>>Cafeteria
                                        </option>
                                        <option value="7" <?php echo e($staff->role == 7 ? 'selected' : ''); ?>>Media</option>
                                    </select>
                                </div>

                                <!-- Password Field (Optional) -->
                                <div class="mb-3">
                                    <label for="password" class="form-label">New Password (Optional)</label>
                                    <div class="input-group">
                                        <input type="password" name="password" id="password" class="form-control"
                                            minlength="8">
                                        <button type="button" class="btn btn-outline-secondary togglePassword">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <small class="text-muted">Leave blank if you do not want to change the
                                        password.</small>
                                </div>
                            </div>

                            <!-- Submit & Cancel Buttons -->
                            <div class="mt-3">
                                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Update
                                    Staff</button>
                                <a href="<?php echo e(route('staff.manage')); ?>" class="btn btn-secondary"><i
                                        class="fas fa-times"></i> Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>

            </main>
            <!-- End Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        // togglePassword
        document.querySelectorAll('.togglePassword').forEach(button => {
            button.addEventListener('click', function() {
                let passwordField = this.previousElementSibling;
                let icon = this.querySelector('i');

                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    icon.classList.replace('fa-eye', 'fa-eye-slash');
                } else {
                    passwordField.type = 'password';
                    icon.classList.replace('fa-eye-slash', 'fa-eye');
                }
            });
        });

        // Generate Staff ID
        document.getElementById('generateStaffId').addEventListener('click', function() {
            const randomNumber = Math.floor(100 + Math.random() * 900); // Generate 3-digit random number
            const staffId = `STA-${randomNumber}`;
            document.getElementById('staff_id').value = staffId;
        });

        // Lock/Unlock Staff ID
        document.getElementById('toggleStaffIdLock').addEventListener('click', function() {
            let staffIdField = document.getElementById('staff_id');
            let lockIcon = document.getElementById('lockIcon');

            if (staffIdField.hasAttribute('readonly')) {
                staffIdField.removeAttribute('readonly'); // Enable Editing
                staffIdField.focus(); // Focus on the field
                lockIcon.classList.replace('fa-lock', 'fa-lock-open'); // Change to Unlocked Icon
            } else {
                staffIdField.setAttribute('readonly', true); // Disable Editing
                lockIcon.classList.replace('fa-lock-open', 'fa-lock'); // Change back to Locked Icon
            }
        });
    </script>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\staffs\edit.blade.php ENDPATH**/ ?>