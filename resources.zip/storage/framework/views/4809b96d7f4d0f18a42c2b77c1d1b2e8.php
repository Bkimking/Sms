<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Edit Sub Course</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Sub Course Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Edit Sub Course</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit Sub Course</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Edit Sub Course page. If you encounter any issues, please contact the developers.
                        <a href="#mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Form for Editing Sub Course -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-edit"></i> Edit Sub Course
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('subcourses.update', $subcourse->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Select Parent Course -->
                            <div class="mb-3">
                                <label for="course_id" class="form-label">Parent Course</label>
                                <select name="course_id" id="course_id" class="form-control" required>
                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($course->id); ?>"
                                            <?php echo e($subcourse->course_id == $course->id ? 'selected' : ''); ?>>
                                            <?php echo e($course->course_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="subcourse_name" class="form-label">Sub Course Name</label>
                                <input type="text" name="subcourse_name" id="subcourse_name" class="form-control"
                                    value="<?php echo e(old('subcourse_name', $subcourse->sub_course_name)); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="subcourse_code" class="form-label">Sub Course Code</label>
                                <input type="text" name="subcourse_code" id="subcourse_code" class="form-control"
                                    value="<?php echo e(old('subcourse_code', $subcourse->sub_course_code)); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="subcourse_description" class="form-label">Sub Course Description</label>
                                <textarea name="subcourse_description" id="subcourse_description" class="form-control" rows="3"><?php echo e(old('subcourse_description', $subcourse->sub_course_description)); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="subcourse_img" class="form-label">Sub Course Image</label>
                                <input type="file" name="subcourse_img" id="subcourse_img" class="form-control">
                            
                                <?php if(!empty($subcourse->sub_course_img) && Storage::disk('public')->exists('subcourses/' . $subcourse->sub_course_img)): ?>
                                    <div class="mt-2">
                                        <img src="<?php echo e(asset('storage/subcourses/' . $subcourse->sub_course_img)); ?>" width="100">
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">No Image Available</span>
                                <?php endif; ?>
                            </div>                            

                            <button type="submit" class="btn btn-primary">Update Sub Course</button>

                            <a href="<?php echo e(route('subcourses.manage')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                        </form>

                    </div>
                </div>
            </main>
            <!-- End Sub Course Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\subcourse\edit.blade.php ENDPATH**/ ?>