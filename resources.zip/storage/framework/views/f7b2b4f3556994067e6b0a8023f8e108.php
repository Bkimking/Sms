<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC - Short Courses</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Short Course Section -->
    <section id="shortcourse" class="container py-5">

        <h1 class="text-center mb-4">Short Courses</h1>
        <p class="text-center mb-5">
            Kenswed TVTC offers a variety of short courses designed to equip you with practical skills
            and knowledge in various fields. These courses are ideal for individuals looking to enhance
            their career opportunities or acquire new skills in a short period.
        </p>

        <div class="row">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(strtolower($course->category) === 'short course'): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="<?php echo e(Storage::url($course->course_img)); ?>" class="card-img-top img-fluid" alt="<?php echo e($course->course_name); ?>" width="300" height="300"><!-- Course Image -->
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($course->course_name); ?></h5> <!-- Course Title -->
                                <p class="card-text"><?php echo e($course->course_description); ?></p> <!-- Course Description -->
                                <a href="<?php echo e(route('course.show', $course->id)); ?>" class="btn btn-danger">Learn More</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>

    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\shortcourses.blade.php ENDPATH**/ ?>