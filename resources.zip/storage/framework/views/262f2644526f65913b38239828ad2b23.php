<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- About Section -->
    <?php if($aboutItem->count() > 0): ?>
        <?php $__currentLoopData = $aboutItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abouts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section id="about" class="container py-5">
                <div class="row">
                    <div class="col-lg-6">
                        <h2><?php echo e($abouts->abouttitle ?? 'Default Title'); ?></h2>
                        <h5><?php echo e($abouts->aboutsubtitle ?? 'Default Subtitle'); ?></h5>
                        <p><?php echo e($abouts->aboutparagraph ?? 'Default paragraph content goes here.'); ?></p>
                    </div>
                    <div class="col-lg-6">
                        <img src="<?php echo e(asset('storage/' . ($abouts->aboutimg ?? 'imgs/logo.jpg'))); ?>"
                            alt="About Kenswed img" class="img-fluid">
                    </div>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No about information available.</p>
    <?php endif; ?>

    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\about.blade.php ENDPATH**/ ?>