<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - View Staff</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">View Staff: <?php echo e($staff->name); ?></h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('staff.manage')); ?>">Manage Staff</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('staff.edit', $staff->id)); ?>">Edit Staff</a></li>
                    <li class="breadcrumb-item active">View Staff</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the View Staff page. If you encounter any issues, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-user"></i> Staff Details
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>Profile Picture</th>
                                <td>
                                    <?php if($staff->profile_pic): ?>
                                        <img src="<?php echo e(asset('storage/' . $staff->profile_pic)); ?>" alt="Profile Picture"
                                            class="img-thumbnail" width="100">
                                    <?php else: ?>
                                        <span class="text-muted">No Profile Picture</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Staff ID</th>
                                <td><?php echo e($staff->staff_id ?? 'Not Assigned'); ?></td>
                            </tr>
                            <tr>
                                <th>First Name</th>
                                <td><?php echo e($staff->firstname ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Middle Name</th>
                                <td><?php echo e($staff->middlename ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Last Name</th>
                                <td><?php echo e($staff->lastname ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Username</th>
                                <td><?php echo e($staff->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($staff->email); ?></td>
                            </tr>
                            <tr>
                                <th>Phone Number</th>
                                <td><?php echo e($staff->phone_number ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><?php echo e($staff->address ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Gender</th>
                                <td><?php echo e(ucfirst($staff->gender ?? 'N/A')); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>
                                    <span
                                        class="badge bg-<?php echo e($staff->status == 'active' ? 'success' : ($staff->status == 'suspended' ? 'danger' : 'warning')); ?>">
                                        <?php echo e(ucfirst($staff->status)); ?>

                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Date Joined</th>
                                <td><?php echo e($staff->created_at ? $staff->created_at->format('d M Y') : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td>
                                    <?php switch($staff->role):
                                        case (1): ?>
                                            Admin
                                        <?php break; ?>

                                        <?php case (3): ?>
                                            Super Admin
                                        <?php break; ?>

                                        <?php case (4): ?>
                                            Teacher
                                        <?php break; ?>

                                        <?php case (5): ?>
                                            Cafeteria
                                        <?php break; ?>

                                        <?php case (7): ?>
                                            Media
                                        <?php break; ?>

                                        <?php default: ?>
                                            Unknown Role
                                    <?php endswitch; ?>
                                </td>
                            </tr>
                        </table>

                        <!-- Back Button -->
                        <a href="<?php echo e(route('staff.manage')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>

            </main>
            <!-- End Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\staffs\view.blade.php ENDPATH**/ ?>