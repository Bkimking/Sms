<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Profile</title>
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="sb-nav-fixed">
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="layoutSidenav">
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div id="layoutSidenav_content">
            <main class="container-fluid px-4">

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('warning')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <?php echo e(session('warning')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Profile</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">View Profile</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the View Profile page. If you encounter any issues, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        Profile for <?php echo e(Auth::user()->name ?? 'User'); ?>

                        <a href="<?php echo e(route('admin.profile.edit')); ?>" class="btn btn-primary btn-sm float-end">Edit
                            Profile</a>
                    </div>
                    <div class="card-body">
                        <div class="row">

                            <!-- Profile Picture -->
                            <div class="col-md-4 text-center">
                                <?php if($admin && $admin->profile_pic): ?>
                                    
                                    <img src="<?php echo e(asset('storage/' . $admin->profile_pic)); ?>" class="img-fluid"
                                        width="200">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('imgs/default_profile.svg')); ?>"
                                        class="img-fluid rounded-circle border border-3 border-secondary"
                                        width="200">
                                    <p class="text-danger mt-2">Please insert your image on the <a
                                            href="<?php echo e(route('admin.profile.edit')); ?>" class="text-primary">edit page</a>.
                                    </p>
                                <?php endif; ?>
                            </div>

                            <!-- Profile Details -->
                            <div class="col-md-8">
                                <table class="table table-borderless table-striped">
                                    <tr>
                                        <th width="30%">First Name:</th>
                                        <td><?php echo e($admin->firstname ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Middle Name:</th>
                                        <td><?php echo e($admin->middlename ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Last Name:</th>
                                        <td><?php echo e($admin->lastname ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone Number:</th>
                                        <td><?php echo e($admin->phone_number ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender:</th>
                                        <td><?php echo e(ucfirst($admin->gender ?? 'N/A')); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Address:</th>
                                        <td><?php echo e($admin->address ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status:</th>
                                        <td>
                                            <?php if($admin): ?>
                                                <span
                                                    class="badge bg-<?php echo e($admin->status == 'active' ? 'success' : ($admin->status == 'suspended' ? 'danger' : 'warning')); ?>">
                                                    <?php echo e(ucfirst($admin->status)); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Incomplete Profile</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                </table>

                                <a href="<?php echo e(route('admin.profile.edit')); ?>" class="btn btn-primary mt-3">Edit
                                    Profile</a>

                                <?php if(!empty($admin->firstname) || !empty($admin->lastname) || !empty($admin->profile_pic)): ?>
                                    <form action="<?php echo e(route('admin.profile.reset')); ?>" method="POST" class="mt-2">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Reset Profile</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\profiles\view.blade.php ENDPATH**/ ?>