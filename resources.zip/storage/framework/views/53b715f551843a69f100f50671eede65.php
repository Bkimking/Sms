<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include Email Verification -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center text-white" style="background-color: #9B1C31;">
                        <h4 class="mb-0"><?php echo e(__('Verify Your Email Address')); ?></h4>
                    </div>
                    <div class="card-body p-4 text-center">
                        <?php if(session('resent')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                            </div>
                        <?php endif; ?>

                        <p class="mb-3">
                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?></p>
                        <p><?php echo e(__('If you did not receive the email')); ?>,</p>

                        <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn text-white" style="background-color: #9B1C31;">
                                <?php echo e(__('Click here to request another')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\auth\verify.blade.php ENDPATH**/ ?>