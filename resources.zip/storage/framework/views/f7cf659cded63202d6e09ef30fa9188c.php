<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Manage Staff</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Manage Staff</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Manage Staff</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Manage Staff page. If you encounter any issues, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Table to Display Staff Members -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-users"></i> Staff List
                        <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-primary btn-sm float-end">+ Add Staff</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Staff ID</th>
                                    <th>Profile Picture</th>
                                    <th>Username</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Address</th>
                                    <th>Gender</th>
                                    <th>Status</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        
                            <tbody>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->staff_id ?? 'Not Assigned'); ?></td>
                                        
                                        <!-- Profile Picture -->
                                        <td>
                                            <?php if($user->profile_pic): ?>
                                                <img src="<?php echo e(asset('storage/' . $user->profile_pic)); ?>" alt="Profile Picture"  width="80">
                                            <?php else: ?>
                                                <span class="text-muted">No Image</span>
                                            <?php endif; ?>
                                        </td>
                        
                                        <td><?php echo e($user->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($user->firstname ?? 'N/A'); ?></td>
                                        <td><?php echo e($user->lastname ?? 'N/A'); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone_number ?? 'N/A'); ?></td>
                                        <td><?php echo e($user->address ?? 'N/A'); ?></td>
                        
                                        <!-- Gender -->
                                        <td><?php echo e(ucfirst($user->gender ?? 'N/A')); ?></td>
                        
                                        <!-- Status Badge -->
                                        <td>
                                            <span class="badge bg-<?php echo e($user->status == 'active' ? 'success' : ($user->status == 'suspended' ? 'danger' : 'warning')); ?>">
                                                <?php echo e(ucfirst($user->status)); ?>

                                            </span>
                                        </td>
                        
                                        <!-- Role -->
                                        <td>
                                            <?php switch($user->role):
                                                case (1): ?> Admin <?php break; ?>
                                                <?php case (3): ?> Super Admin <?php break; ?>
                                                <?php case (4): ?> Teacher <?php break; ?>
                                                <?php case (5): ?> Cafeteria <?php break; ?>
                                                <?php case (7): ?> Media <?php break; ?>
                                                <?php default: ?> Unknown
                                            <?php endswitch; ?>
                                        </td>
                        
                                        <!-- Actions -->
                                        <td>
                                            <a href="<?php echo e(route('staff.view', $user->id)); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                        
                                            <a href="<?php echo e(route('staff.edit', $user->id)); ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                        
                                            <form action="<?php echo e(route('staff.destroy', $user->id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this staff member?');">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
                <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> Add New Staff
                </a>
            </main>
            <!-- End Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\staffs\manage.blade.php ENDPATH**/ ?>