<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Profile</title>
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body class="sb-nav-fixed">
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="layoutSidenav">
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div id="layoutSidenav_content">
            <main class="container-fluid px-4">

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('warning')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <?php echo e(session('warning')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Profile</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit Profile</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Edit Profile page. If you encounter any issues, please contact the developers.
                        <a href="#mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        Update Profile
                        <?php if(Auth::user()->admin && Auth::user()->admin->firstname): ?>
                            <a href="<?php echo e(route('admin.profile.view')); ?>" class="btn btn-primary btn-sm float-end">View
                                Profile</a>
                        <?php endif; ?>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('admin.profile.update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label>First Name:</label>
                                <input type="text" name="firstname" class="form-control"
                                    value="<?php echo e(old('firstname', $admin->firstname ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label>Middle Name:</label>
                                <input type="text" name="middlename" class="form-control"
                                    value="<?php echo e(old('middlename', $admin->middlename ?? '')); ?>">
                            </div>

                            <div class="mb-3">
                                <label>Last Name:</label>
                                <input type="text" name="lastname" class="form-control"
                                    value="<?php echo e(old('lastname', $admin->lastname ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label>Phone Number:</label>
                                <input type="text" name="phone_number" class="form-control"
                                    value="<?php echo e(old('phone_number', $admin->phone_number ?? '')); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label>Address:</label>
                                <input type="text" name="address" class="form-control"
                                    value="<?php echo e(old('address', $admin->address ?? '')); ?>" required>
                            </div>

                            <!-- Gender Selection -->
                            <div class="mb-3">
                                <label>Gender:</label>
                                <select name="gender" class="form-control" required>
                                    <option value="" disabled selected>Select Gender</option>
                                    <option value="male"
                                        <?php echo e(old('gender', $admin->gender ?? '') == 'male' ? 'selected' : ''); ?>>Male
                                    </option>
                                    <option value="female"
                                        <?php echo e(old('gender', $admin->gender ?? '') == 'female' ? 'selected' : ''); ?>>Female
                                    </option>
                                </select>
                            </div>

                            <!-- Profile Picture -->
                            <div class="mb-3">
                                <label>Profile Picture:</label>
                                <input type="file" name="profile_pic" class="form-control">
                            </div>

                            <!-- Current Profile Picture -->
                            <?php if(Auth::user()->admin && Auth::user()->admin->profile_pic): ?>
                                <div class="mb-3">
                                    <p class="mb-1">Current Profile Picture:</p>
                                    <img src="<?php echo e(asset('storage/' . (Auth::user()->admin->profile_pic ?? 'default_profile.svg'))); ?>"
                                        class="img-thumbnail" width="150" height="150" alt="Profile Picture">
                                </div>
                            <?php endif; ?>

                            <!-- Submit Button -->
                            <button type="submit" class="btn btn-success">Update Profile</button>

                        </form>
                        <?php if(!empty($admin->firstname) || !empty($admin->lastname) || !empty($admin->profile_pic)): ?>
                        <form action="<?php echo e(route('admin.profile.reset')); ?>" method="POST" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Reset Profile</button>
                        </form>
                    <?php endif; ?>
                    </div>
                </div>
            </main>
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\student\profile\edit.blade.php ENDPATH**/ ?>