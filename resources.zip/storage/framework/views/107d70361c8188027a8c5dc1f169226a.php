<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($subCourse->sub_course_name); ?> - Kenswed TVTC</title>
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section id="subcourseshow" class="container py-5">
        <h1 class="text mb-4"><?php echo e($subCourse->sub_course_name); ?></h1>

        <div class="row">
            <!-- Left Section (80%) -->
            <div class="col-md-8">
                <?php if(!empty($subCourse->sub_course_img) && Storage::disk('public')->exists('subcourses/' . $subCourse->sub_course_img)): ?>
                    <img src="<?php echo e(asset('storage/subcourses/' . $subCourse->sub_course_img)); ?>" class="img-fluid mb-4"
                        width="300" height="300" alt="<?php echo e($subCourse->sub_course_name); ?>">
                <?php endif; ?>

                <p><?php echo e($subCourse->sub_course_description); ?></p>

                <div class="mt-4">
                    <a href="<?php echo e(route('course.show', $course->id)); ?>" class="btn btn-secondary">
                        Back to <?php echo e($course->course_name); ?>

                    </a>
                    <!-- Apply for Subcourse -->
                    <a href="<?php echo e(route('apply.page', ['type' => 'subcourse', 'id' => $subCourse->id])); ?>" class="btn btn-danger">Apply for Subcourse</a>
                </div>
            </div>

            <!-- Right Section (20%) -->
            <div class="col-md-4">
                <!-- Card: Other Sub-Courses -->
                <?php if($otherSubCourses->count() > 0): ?>
                    <div class="card mb-4">
                        <div class="card-header bg-danger text-white">Other Sub-Courses in <?php echo e($course->course_name); ?>

                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $otherSubCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherSubCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('subcourses.show', $otherSubCourse->id)); ?>">
                                            <?php echo e($otherSubCourse->sub_course_name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        </div> <!-- End of Row -->
    </section>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\showsubcourse.blade.php ENDPATH**/ ?>