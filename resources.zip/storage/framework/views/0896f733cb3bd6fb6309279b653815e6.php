<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Manage Courses</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Course Management Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Manage Courses</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('departments.manage')); ?>">Manage Departments</a></li>
                    <li class="breadcrumb-item active">Manage Courses</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Manage Courses page. If you encounter any issues, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Table to Display Courses -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Course List
                        <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary btn-sm float-end">+ Add course</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Course Name</th>
                                    <th>Course Code</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Department</th>
                                    <th>Teacher</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($course->id); ?></td>
                                        <td><?php echo e($course->course_name); ?></td>
                                        <td><?php echo e($course->course_code); ?></td>
                                        <td><?php echo e($course->course_description); ?></td>
                                        <td><?php echo e($course->category); ?></td>
                                        <td><?php echo e($course->department->department_name ?? 'Not Assigned'); ?></td>
                                        <td><?php echo e($course->teacher->name ?? 'Not Assigned'); ?></td>

                                        <td>
                                            <a href="<?php echo e(route('courses.edit', $course->id)); ?>"
                                                class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <!-- Delete button -->
                                            <form action="<?php echo e(route('courses.destroy', $course->id)); ?>"
                                                method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Are you sure you want to delete this course?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> Add New Course
                </a>
            </main>
            <!-- End Course Management Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\courses\manage.blade.php ENDPATH**/ ?>