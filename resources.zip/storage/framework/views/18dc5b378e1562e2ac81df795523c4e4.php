<!-- this is footer for superadmin -->

<!-- footer -->

<!-- footer section -->
<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Kenswed TVTC <?php echo e(date('Y')); ?></div>
            <div>
                <p>Developed by <a href="https://codewithsky.co.ke" target="_blank" class="footer-link">Code With Sky</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- End footer --><?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\superadmin\includes\footer.blade.php ENDPATH**/ ?>