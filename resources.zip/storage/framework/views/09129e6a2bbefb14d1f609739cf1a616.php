<!-- this is dashboard for student -->

<!-- dashboard -->

<!DOCTYPE html>
<html lang="en">

<head>

    <title>student Dashboard</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.student.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->

</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.student.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.student.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Main Content -->

            <main>
                <div class="container-fluid px-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('warning')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?php echo e(session('warning')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Welcome, <?php echo e(Auth::user()->name); ?>!</h1>
                        <p class="lead">This is your student dashboard</p>

                        <!-- Course Overview -->
                        <div class="row">
                            <div class="col-xl-4 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">My Courses</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link"
                                            href="<?php echo e(route('student.courses')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-arrow-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Assignments Due</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link"
                                            href="<?php echo e(route('student.assignments')); ?>">Check Now</a>
                                        <div class="small text-white"><i class="fas fa-arrow-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Exam Schedule</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link"
                                            href="<?php echo e(route('student.exams')); ?>">View</a>
                                        <div class="small text-white"><i class="fas fa-arrow-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Latest Announcements -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-bullhorn me-1"></i>
                                Announcements
                            </div>
                            <div class="card-body">
                                <ul>
                                    <li>New Assignment: Project Proposal (Due in 3 days)</li>
                                    <li>Upcoming Exam: Mathematics (March 15)</li>
                                    <li>School Event: Hackathon Registration Open!</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <!-- End Main Content -->


            <!-- Footer -->
            <?php echo $__env->make('kenswed.student.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.student.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\student\dashboard.blade.php ENDPATH**/ ?>