<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Dashboard - Manage Sub Courses</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Sub Course Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Manage Sub Courses</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('courses.manage')); ?>">Manage Courses</a></li>
                    <li class="breadcrumb-item active">Manage Sub Courses</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Manage Sub Course page. If you encounter any issues, please contact the developers.
                        <a href="#mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <!-- Sub Course Table -->
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table"></i> Sub Courses List
                        <a href="<?php echo e(route('subcourses.create')); ?>" class="btn btn-primary btn-sm float-end">+ Add Sub
                            Courses</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Sub Course Name</th>
                                    <th>Sub Course Code</th>
                                    <th>Image</th>
                                    <th>Parent Course</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $subcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($subcourse->id); ?></td>
                                        <td><?php echo e($subcourse->sub_course_name ?? 'N/A'); ?></td>
                                        <td><?php echo e($subcourse->sub_course_code ?? 'N/A'); ?></td>
                                        <td>
                                            <?php if(!empty($subcourse->sub_course_img) && Storage::disk('public')->exists('subcourses/' . $subcourse->sub_course_img)): ?>
                                                <img src="<?php echo e(asset('storage/subcourses/' . $subcourse->sub_course_img)); ?>"
                                                    width="50" height="50" class="rounded">
                                            <?php else: ?>
                                                <span class="text-muted">No Image</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($subcourse->course): ?>
                                                <?php echo e($subcourse->course->course_name); ?>

                                            <?php else: ?>
                                                <span class="text-danger">No Course Assigned</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('subcourses.edit', $subcourse->id)); ?>"
                                                class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('subcourses.destroy', $subcourse->id)); ?>"
                                                method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this subcourse?');">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No Sub Courses Available</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <a href="<?php echo e(route('subcourses.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> Add New Sub Course
                </a>
            </main>
            <!-- End Sub Course Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->
</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\subcourse\manage.blade.php ENDPATH**/ ?>