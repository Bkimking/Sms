<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit Course</title>

    <!-- Include Head -->
    <?php echo $__env->make('kenswed.admin.includes.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Head -->
</head>

<body class="sb-nav-fixed">

    <!-- Navbar -->
    <?php echo $__env->make('kenswed.admin.includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Navbar -->

    <div id="layoutSidenav">

        <!-- Sidebar -->
        <?php echo $__env->make('kenswed.admin.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End Sidebar -->

        <div id="layoutSidenav_content">

            <!-- Course Content -->
            <main class="container-fluid px-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <h1 class="mt-4">Edit Course</h1>

                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit Course</li>
                </ol>

                <div class="card mb-4">
                    <div class="card-body">
                        This is the Edit Course page. If you encounter any issues, please contact the developers.
                        <a href="mailto:developers@example.com">Contact Developers</a>.
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-edit"></i> Edit Course
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('courses.update', $course->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label for="course_name" class="form-label">Course Name</label>
                                <input type="text" name="course_name" id="course_name" class="form-control" required
                                    value="<?php echo e($course->course_name); ?>">
                            </div>

                            <div class="mb-3">
                                <label for="course_code" class="form-label">Course Code</label>
                                <input type="text" name="course_code" id="course_code" class="form-control" required
                                    value="<?php echo e($course->course_code); ?>">
                            </div>

                            <div class="mb-3">
                                <label for="course_description" class="form-label">Course Description</label>
                                <textarea name="course_description" id="course_description" class="form-control" rows="3"><?php echo e($course->course_description); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="course_img" class="form-label">Course Image</label>
                                <input type="file" name="course_img" id="course_img" class="form-control">
                                <?php if($course->course_img): ?>
                                    <p>Current Image:</p>
                                    <img src="<?php echo e(asset('storage/' . $course->course_img)); ?>" width="100">
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="depart_id" class="form-label">Department</label>
                                <select name="depart_id" id="depart_id" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"
                                            <?php echo e($course->depart_id == $department->id ? 'selected' : ''); ?>>
                                            <?php echo e($department->department_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="teacher_id" class="form-label">Teacher</label>
                                <select name="teacher_id" id="teacher_id" class="form-control">
                                    <option value="">Select Teacher</option>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($teacher->id); ?>"
                                            <?php echo e($course->teacher_id == $teacher->id ? 'selected' : ''); ?>>
                                            <?php echo e($teacher->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="category" class="form-label">Course Category</label>
                                <select name="category" id="category" class="form-control" required>
                                    <option value="Certificate"
                                        <?php echo e($course->category == 'Certificate' ? 'selected' : ''); ?>>Certificate</option>
                                    <option value="Diploma" <?php echo e($course->category == 'Diploma' ? 'selected' : ''); ?>>
                                        Diploma</option>
                                    <option value="Short Course"
                                        <?php echo e($course->category == 'Short Course' ? 'selected' : ''); ?>>Short Course
                                    </option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Update Course</button>
                            <a href="<?php echo e(route('admin')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                            <a href="<?php echo e(route('courses.manage')); ?>" class="btn btn-warning">Manage Courses</a>
                        </form>
                    </div>
                </div>
            </main>
            <!-- End Course Content -->

            <!-- Footer -->
            <?php echo $__env->make('kenswed.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- End Footer -->

        </div>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('kenswed.admin.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Scripts -->

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\kenswed\admin\courses\edit.blade.php ENDPATH**/ ?>