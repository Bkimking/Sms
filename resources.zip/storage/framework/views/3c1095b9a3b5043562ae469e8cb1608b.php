<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kenswed TVTC</title>
    <!-- Include head -->
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <style>
        #mission {
            background-color: #f8f9fa;
            padding: 50px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        #mission h2 {
            color: #007bff;
            margin-bottom: 20px;
            font-weight: bold;
        }

        #mission p {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #6c757d;
            margin-bottom: 30px;
        }

        #mission .mission-images {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        #mission .mission-images img {
            max-width: 300px;
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <!-- Include header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Mission Section -->
    <section id="mission" class="container my-5">
        <h2>Our Mission</h2>
        <p>
            At Kenswed TVTC, our mission is to empower individuals with practical and professional skills that prepare
            them for success in their careers and communities. We are dedicated to excellence in training, nurturing
            talent, and fostering innovation in every student. Our goal is to create an environment where every learner
            can thrive, innovate, and contribute positively to society.
        </p>
        <div class="mission-images">
            <img src="imgs/IMG_8551.jpg" alt="Kenswed Campus">
            <img src="imgs/IMG_8559.jpg" alt="Students Engaged in Learning">
            <img src="imgs/_MG_9940.jpg" alt="Hands-On Training Workshop">
        </div>
    </section>

    <!-- Include footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Include scripts -->
    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\Brian\Desktop\kenswed\resources\views\mission.blade.php ENDPATH**/ ?>